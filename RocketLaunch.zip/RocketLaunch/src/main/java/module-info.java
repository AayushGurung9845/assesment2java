module org.example.rocketlaunch {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.net.http;
    requires com.google.gson;

    opens org.example.rocketlaunch to javafx.fxml, com.google.gson;
    exports org.example.rocketlaunch;
}