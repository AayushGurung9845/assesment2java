package org.example.rocketlaunch;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.List;

public class MainView extends BorderPane {
    private ListView<Launch> launchListView;
    private Button refreshButton;
    private Button viewDetailsButton;
    private TextField searchField;
    private Button searchButton;

    public MainView() {
        initializeComponents();
        layoutComponents();
        styleComponents();
    }

    private void initializeComponents() {
        launchListView = new ListView<>();
        refreshButton = new Button("Refresh Launches");
        viewDetailsButton = new Button("View Details");
        searchField = new TextField();
        searchButton = new Button("Search");
    }

    private void layoutComponents() {
        HBox searchBox = new HBox(10, searchField, searchButton);
        VBox buttonBox = new VBox(10, refreshButton, viewDetailsButton, searchBox);
        buttonBox.setPadding(new Insets(10));

        setCenter(launchListView);
        setRight(buttonBox);

        BorderPane.setMargin(launchListView, new Insets(10));
    }

    private void styleComponents() {
        setStyle("-fx-background-color: #f0f0f0;");
        refreshButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        viewDetailsButton.setStyle("-fx-background-color: #008CBA; -fx-text-fill: white;");
        searchButton.setStyle("-fx-background-color: #FFA500; -fx-text-fill: white;");

        refreshButton.setMaxWidth(Double.MAX_VALUE);
        viewDetailsButton.setMaxWidth(Double.MAX_VALUE);
        searchButton.setMaxWidth(Double.MAX_VALUE);

        searchField.setPromptText("Enter search term");

        launchListView.setStyle("-fx-background-color: white; -fx-border-color: #cccccc;");
    }

    public void updateLaunchList(List<Launch> launches) {
        launchListView.getItems().clear();
        launchListView.getItems().addAll(launches);
    }

    public ListView<Launch> getLaunchListView() { return launchListView; }
    public Button getRefreshButton() { return refreshButton; }
    public Button getViewDetailsButton() { return viewDetailsButton; }
    public TextField getSearchField() { return searchField; }
    public Button getSearchButton() { return searchButton; }
}