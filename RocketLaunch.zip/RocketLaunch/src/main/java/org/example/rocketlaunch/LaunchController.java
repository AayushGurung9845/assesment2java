package org.example.rocketlaunch;

import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.List;

public class LaunchController {
    private LaunchModel model;
    private MainView mainView;
    private DetailView detailView;
    private Stage primaryStage;
    private Scene mainScene;
    private Scene detailScene;

    public LaunchController(LaunchModel model, MainView mainView, DetailView detailView, Stage primaryStage, Scene mainScene, Scene detailScene) {
        this.model = model;
        this.mainView = mainView;
        this.detailView = detailView;
        this.primaryStage = primaryStage;
        this.mainScene = mainScene;
        this.detailScene = detailScene;

        setUpEventHandlers();
    }

    private void setUpEventHandlers() {
        mainView.getRefreshButton().setOnAction(e -> refreshLaunches());
        mainView.getViewDetailsButton().setOnAction(e -> showDetailView());
        detailView.getBackButton().setOnAction(e -> showMainView());
        mainView.getSearchButton().setOnAction(e -> searchLaunches());
    }

    private void refreshLaunches() {
        model.fetchLaunches();
        mainView.updateLaunchList(model.getLaunches());
    }

    private void showDetailView() {
        Launch selectedLaunch = mainView.getLaunchListView().getSelectionModel().getSelectedItem();
        if (selectedLaunch != null) {
            detailView.showLaunchDetails(selectedLaunch);
            primaryStage.setScene(detailScene);
        }
    }

    private void showMainView() {
        primaryStage.setScene(mainScene);
    }

    private void searchLaunches() {
        String searchTerm = mainView.getSearchField().getText().toLowerCase();
        List<Launch> searchResults = model.searchLaunches(searchTerm);
        mainView.updateLaunchList(searchResults);
    }

    public void initialize() {
        refreshLaunches();
        showMainView();
    }
}