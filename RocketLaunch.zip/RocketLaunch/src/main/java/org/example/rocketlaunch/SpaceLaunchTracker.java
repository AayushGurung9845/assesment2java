package org.example.rocketlaunch;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class SpaceLaunchTracker extends Application {
    @Override
    public void start(Stage primaryStage) {
        LaunchModel model = new LaunchModel();
        MainView mainView = new MainView();
        DetailView detailView = new DetailView();

        Scene mainScene = new Scene(mainView, 800, 600);
        Scene detailScene = new Scene(detailView, 600, 400);

        LaunchController controller = new LaunchController(model, mainView, detailView, primaryStage, mainScene, detailScene);

        controller.initialize();

        primaryStage.setTitle("Space Launch Tracker");
        primaryStage.setScene(mainScene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}