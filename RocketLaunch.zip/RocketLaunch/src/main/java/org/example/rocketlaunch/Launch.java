package org.example.rocketlaunch;

public class Launch {
    private String name;
    private String date;
    private String location;
    private String rocketName;

    public Launch(String name, String date, String location, String rocketName) {
        this.name = name;
        this.date = date;
        this.location = location;
        this.rocketName = rocketName;
    }

    public String getName() { return name; }
    public String getDate() { return date; }
    public String getLocation() { return location; }
    public String getRocketName() { return rocketName; }

    @Override
    public String toString() {
        return name + " - " + date;
    }
}